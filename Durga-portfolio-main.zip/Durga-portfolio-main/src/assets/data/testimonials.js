const testimonials = [
  {
    id: 1,
    name: 'Shaif Arfan',
    title: 'CEO',
    org: 'WEB CIFAR',
    desc:
      'Durga is a person of commitment. He is really good at what he is doing. I really like his work.',
  },
  {
    id: 2,
    name: 'Savitha Dongre',
    title: 'Project Manager',
    desc:
      'Really amazing communication skills. Always understand what I am trying to achieve. Also, his work is really amazing. Do really high-quality work.',
  },
  {
    id: 3,
    name: 'Navya',
    title: 'Team Member',
    desc:
      'Really hard-working person. Deliver the work as promised. Planning to work more with this person.',
  },
];
export default testimonials;
